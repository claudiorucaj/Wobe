/* Vite configuration with optimized aliases */
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';
import { visualizer } from 'rollup-plugin-visualizer';

export default defineConfig({
  appName: 'Wobe',
  plugins: [
    react(),
    visualizer({ open: true }) // Visualize bundle sizes
  ],
  resolve: {
    alias: {
      '@components': resolve(__dirname, './src/components'),
      '@utils': resolve(__dirname, './src/utils'),
      '@types': resolve(__dirname, './src/types'),
    },
  },
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          react: ['react', 'react-dom'],
          vendor: ['@vitejs/plugin-react'],
        },
      },
    },
    sourcemap: true // Enable sourcemaps for debugging
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
});
