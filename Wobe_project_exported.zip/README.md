# Wobe Project

This is the exported structure for the Wobe project.

## How to Run
1. Install dependencies:
```
npm install
```
2. Start the development server:
```
npm run dev
```
